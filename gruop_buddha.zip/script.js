var topt = document.getElementById('top')
var ltr = document.getElementById('ltr')
var left = document.getElementById('left')
var right = document.getElementById('right')
var b_left = document.querySelectorAll('.b_left')
var b_right = document.querySelectorAll('.b_right')
var main_row1 = document.getElementById('main_row1')
var main_row2 = document.getElementById('main_row2')
var main_row3 = document.getElementById('main_row3')


var bottom = document.getElementById('bottom')
var main_row1_col = document.querySelectorAll('.main_row1_col')

function imgInsert(l, el, clsName, pic) {
    for (var i = 0; i < l; i++) {
        var img = document.createElement('img')
        img.className = clsName
        img.src = `./img/${pic}.jpg`
        el.appendChild(img)
    }

}
imgInsert(39, topt, 'borderTopBottom', 'border_top(1)')
imgInsert(40, bottom, 'borderTopBottom', 'border_top(1)')
imgInsert(32, left, 'borderLeftRight', 'border_left_or_right(1)')
imgInsert(32, right, 'borderLeftRight', 'border_left_or_right(1)')

var buddha_name = [
    [`১.  ভগবান অরহত্  তৃষ্ণাংকর সম্যক সম্বুদ্ধ`,
        `২. ভগবান অরহত্  মেধাংকর সম্যক সম্বুদ্ধ`,
        `৩. ভগবান অরহত্  শরণংকর সম্যক সম্বুদ্ধ`],
    [`৪. ভগবান অরহত্  দীপংকর সম্যক সম্বুদ্ধ`,
        `৫. ভগবান অরহত্  কোণ্ডাণ্য সম্যক সম্বুদ্ধ`,
        `৬. ভগবান অরহত্  মঙ্গল সম্যক সম্বুদ্ধ`],
    [`৭. ভগবান অরহত্  সুমন সম্যক সম্বুদ্ধ`,
        `৮. ভগবান অরহত্  রেবত সম্যক সম্বুদ্ধ`,
        `৯. ভগবান অরহত্  সোভিত সম্যক সম্বুদ্ধ`],
    [`১০. ভগবান অরহত্  অনোমদর্শী সম্যক সম্বুদ্ধ`,
        `১১. ভগবান অরহত্  পদুম সম্যক সম্বুদ্ধ`,
        `১২. ভগবান অরহত্  নারদ সম্যক সম্বুদ্ধ`],
    [`১৩. ভগবান অরহত্  পদুমুত্তর সম্যক সম্বুদ্ধ`,
        `১৪. ভগবান অরহত্ সুমেধ সম্যক সম্বুদ্ধ`,
        `১৫. ভগবান অরহত্  সুজাত সম্যক সম্বুদ্ধ`],
    [`১৬. ভগবান অরহত্  প্রিয়দর্শী সম্যক সম্বুদ্ধ`,
        `১৭. ভগবান অরহত্  অর্থদর্শী সম্যক সম্বুদ্ধ`,
        `১৮. ভগবান অরহত্  ধর্মদর্শী সম্যক সম্বুদ্ধ`],
    [`১৯. ভগবান অরহত্ সিদ্ধার্থ সম্যক সম্বুদ্ধ`,
        `২০. ভগবান অরহত্  তিষ্য সম্যক সম্বুদ্ধ`,
        `২১. ভগবান অরহত্  ফুষ্য সম্যক সম্বুদ্ধ`],
    [`২২. ভগবান অরহত্  বিপর্শী সম্যক সম্বুদ্ধ`,
        `২৩. ভগবান অরহত্  সিখী সম্যক সম্বুদ্ধ`,
        `২৪. ভগবান অরহত্  বেষ্যভূ সম্যক সম্বুদ্ধ`],
    [`২৫. ভগবান অরহত্  ককুসন্দ সম্যক সম্বুদ্ধ`,
        `২৬. ভগবান অরহত্ কোনাগমন সম্যক সম্বুদ্ধ`,
        `২৭. ভগবান অরহত্  কাশ্যপ সম্যক সম্বুদ্ধ`],
    [`২৮. ভগবান অরহত্ গৌতম সম্যক সম্বুদ্ধ`,
        `বুদ্ধগয়ার বুদ্ধ`,
        `বুদ্ধের পবিত্র শারিরীক ধাতু`]
]

function buddhaInset(el, arr, num) {
    var t_arr = []
    for (var i = 0; i < arr.length; i++) {
        t_arr.push(`<div class="photo">
                        <div class="img_div">
                            <img class="img_single" src="./img/buddha(${i + num}).jpg">
                            <p class="name">${arr[i]}</p>
                        </div>
                    </div>`)
    }
    el.innerHTML = t_arr.join('')
}

function otherInset(el, arr, num) {
    var t_arr = []
    for (var i = 0; i < arr.length; i++) {
        t_arr.push(`<div class="photo">
                        <div class="img_div">
                            <img class="other" src="./img/other(${i + num}).jpg">
                            <p class="name">${arr[i]}</p>
                        </div>
                    </div>`)
    }
    el.innerHTML = t_arr.join('')
}

buddhaInset(b_left[0], buddha_name[0], 1)
buddhaInset(b_left[1], buddha_name[2], 7)
buddhaInset(b_left[2], buddha_name[4], 13)
buddhaInset(b_left[3], buddha_name[6], 19)
buddhaInset(b_left[4], buddha_name[8], 25)

buddhaInset(b_right[0], buddha_name[1], 4)
buddhaInset(b_right[1], buddha_name[3], 10)
buddhaInset(b_right[2], buddha_name[5], 16)
buddhaInset(b_right[3], buddha_name[7], 22)
buddhaInset(b_right[4], buddha_name[9], 28)


var other1 = [
    'কাপ্তাই চিৎমরম বুদ্ধ',
    'ছয় রং বুদ্ধ পতাকা',
    'আর্যঅষ্টাঙ্গিক ধর্মচক্র',
    'চারি আর্যসত্য',
    'অভিধর্মের ২৪ প্রত্যয়',
    'বুদ্ধের সাধনার বজ্রাসন',
    'মহাবোধি সত্ত্ব সিদ্ধার্থ',
    'লাভীশ্রেষ্ঠ পূজনীয় সীবলী ভান্তে',
    'মারবিজয়ী পূজনীয় উপগুপ্ত ভান্তে',
    'অর্হৎ পূজনীয় মোগক ছেয়াদ ভান্তে'
]
var other2 = [
    'পূজনীয় সামাঞ্ঞাতাং ছেয়াদ ভান্তে',
    'পূজনীয় উঃ কোবি ছেয়াদ ভান্তে',
    'পূজনীয় উত্তমাসার ছেয়াদ ভান্তে',
    '২য় সংঘরাজ পূজনীয় গুণালংকার ভান্তে',
    'অর্হৎ পূজনীয় বনভান্তে',
    'সাধক পূজনীয় প্রজ্ঞাজ্যোতি ভান্তে',
    'পণ্ডিত পূজনীয় প্রজ্ঞাবংশ ভান্তে',
    'পূজনীয় প্রজ্ঞালংকার ভান্তে',
    'পূজনীয় শীলানন্দ ভান্তে',
    'পূজনীয় ধর্মরত্ন ভান্তে'
]
otherInset(main_row2, other1, 1)
otherInset(main_row3, other2, 11)

var t_m_width = main_row1.clientWidth
var img_single = document.querySelectorAll('.img_single')
var s_m_width = t_m_width/10
for (var i = 0; i < img_single.length; i++) {
    img_single[i].setAttribute('style', `width: ${s_m_width }px; height: ${s_m_width + 54}px`)
}


var other = document.querySelectorAll('.other')
var s_m_width = t_m_width/10
for (var i = 0; i < other.length; i++) {
    other[i].setAttribute('style', `width: ${s_m_width + 25}px; height: ${s_m_width + 54}px`)
}
var h = main_row1_col[0].clientHeight
 h -= 100
document.querySelector('.big_buddha_img').setAttribute('style', `height: ${h}px;`)

var item = document.querySelectorAll('.item')

function imgInsert_btm(l, el, clsName, pic) {
    for (var i = 0; i < l; i++) {
        var img = document.createElement('img')
        img.className = clsName
        img.src = `./${pic}.png`
        el.appendChild(img)
    }

}

imgInsert_btm(46, item[0], 'end', 'flower' )
imgInsert_btm(46, item[1], 'end', 'flower' )


other[3].setAttribute('src', './img/other(4).png')
other[12].setAttribute('src', './img/other(13).png')
var borderTopBottom = document.querySelectorAll('.borderTopBottom')
var md = borderTopBottom.length/2 - 1
var ln = borderTopBottom.length - 1
// borderTopBottom[md].setAttribute('src', './img/border_top_end.jpg')
// borderTopBottom[ln].setAttribute('src', './img/border_top_end.jpg')
var bigbuddha = document.querySelector('.bigbuddha')

var bigbuddha_width = bigbuddha.clientWidth
var fpuja = document.getElementById('fpuja')
var flower_puja = document.getElementById('flower_puja')

fpuja.style.width = bigbuddha_width-50 + 'px'
flower_puja.style.marginTop = '-' + fpuja.clientHeight + 'px'